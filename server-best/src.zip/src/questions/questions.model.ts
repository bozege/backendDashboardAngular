export interface QuestionModel {
    question: string
    options: Array<string>;
}